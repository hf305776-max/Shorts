"""
Genera los recursos de ejemplo (imagenes y audio) para que el proyecto
renderice de inmediato. Requiere: python3, numpy, pillow.
Uso:  python3 scripts/generate_placeholders.py
Reemplaza luego los archivos de /public por los tuyos (mismo nombre o
cambia las rutas en src/config.ts).
"""
import os
import wave
import numpy as np
from PIL import Image, ImageFilter, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IMG = os.path.join(ROOT, "public", "images")
AUD = os.path.join(ROOT, "public", "audio")
os.makedirs(IMG, exist_ok=True)
os.makedirs(AUD, exist_ok=True)

rng = np.random.default_rng(7)

# ---------------------------------------------------------------- imagenes
W, H = 1080, 1920
PALETTES = [
    ((6, 10, 26), (20, 60, 110), (255, 150, 60)),
    ((14, 6, 20), (90, 25, 70), (255, 90, 120)),
    ((4, 18, 20), (10, 80, 90), (120, 255, 220)),
    ((18, 10, 4), (110, 55, 15), (255, 200, 90)),
    ((8, 8, 20), (45, 30, 110), (160, 140, 255)),
    ((10, 10, 10), (60, 20, 20), (255, 60, 60)),
]


def make_image(i, top, mid, glow):
    y = np.linspace(0, 1, H)[:, None, None]
    top = np.array(top, dtype=np.float32)
    mid = np.array(mid, dtype=np.float32)
    base = top * (1 - y) + mid * y
    base = np.repeat(base, W, axis=1)

    xx, yy = np.meshgrid(np.linspace(-1, 1, W), np.linspace(-1, 1, H))
    cx, cy = rng.uniform(-0.4, 0.4), rng.uniform(-0.2, 0.3)
    d = np.sqrt((xx - cx) ** 2 + ((yy - cy) * 0.6) ** 2)
    g = np.exp(-(d**2) / 0.12)[..., None]
    base = base + g * np.array(glow, dtype=np.float32) * 0.55

    img = Image.fromarray(np.clip(base, 0, 255).astype(np.uint8))

    bokeh = Image.new("RGB", (W, H), (0, 0, 0))
    dr = ImageDraw.Draw(bokeh)
    for _ in range(26):
        r = int(rng.integers(30, 150))
        x, yv = int(rng.integers(0, W)), int(rng.integers(0, H))
        k = rng.uniform(0.15, 0.5)
        col = tuple(int(c * k) for c in glow)
        dr.ellipse((x - r, yv - r, x + r, yv + r), fill=col)
    bokeh = bokeh.filter(ImageFilter.GaussianBlur(28))
    arr = np.asarray(img, dtype=np.float32) + np.asarray(bokeh, dtype=np.float32) * 0.6
    arr += rng.normal(0, 3.0, arr.shape)
    out = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8))
    out.save(os.path.join(IMG, f"scene-{i}.jpg"), quality=88)


for n, p in enumerate(PALETTES, start=1):
    make_image(n, *p)
print("Imagenes OK")

# ------------------------------------------------------------------- audio
SR = 44100


def write_wav(name, data):
    data = np.clip(data, -1, 1)
    pcm = (data * 32767).astype(np.int16)
    with wave.open(os.path.join(AUD, name), "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(SR)
        f.writeframes(pcm.tobytes())


def tone(freq, t, harmonics=(1, 0.5, 0.25, 0.12)):
    s = np.zeros_like(t)
    for h, a in enumerate(harmonics, start=1):
        s += a * np.sin(2 * np.pi * freq * h * t)
    return s


# Musica: pad cinematografico en La menor + pulso grave + notas agudas
DUR = 32.0
t = np.arange(int(SR * DUR)) / SR
pad = np.zeros_like(t)
for f in (110.0, 130.81, 164.81, 220.0):
    lfo = 0.6 + 0.4 * np.sin(2 * np.pi * (0.07 + f / 5000) * t)
    pad += tone(f, t) * lfo * 0.12
    pad += tone(f * 1.003, t) * lfo * 0.08
bpm = 90.0
beat = 60.0 / bpm
pulse = np.zeros_like(t)
for k in range(int(DUR / beat)):
    s0 = int(k * beat * SR)
    n = int(0.35 * SR)
    seg = np.arange(n) / SR
    env = np.exp(-seg * 9)
    amp = 0.55 if k % 4 == 0 else 0.3
    kick = np.sin(2 * np.pi * (48 + 60 * np.exp(-seg * 25)) * seg) * env * amp
    end = min(s0 + n, len(pulse))
    pulse[s0:end] += kick[: end - s0]
notes = [220.0, 261.63, 329.63, 392.0, 329.63, 261.63]
pluck = np.zeros_like(t)
step = beat / 2
for k in range(int(DUR / step)):
    s0 = int(k * step * SR)
    n = int(0.6 * SR)
    seg = np.arange(n) / SR
    f = notes[k % len(notes)] * 2
    n_env = np.exp(-seg * 5)
    v = np.sin(2 * np.pi * f * seg) * n_env * 0.06
    end = min(s0 + n, len(pluck))
    pluck[s0:end] += v[: end - s0]
music = pad + pulse * 0.5 + pluck
music /= np.max(np.abs(music)) * 1.15
write_wav("music.wav", music)

# Whoosh: ruido filtrado con barrido
n = int(0.7 * SR)
tt = np.arange(n) / SR
noise = rng.normal(0, 1, n)
out = np.zeros(n)
prev = 0.0
for i in range(n):
    p = i / n
    a = 0.02 + 0.55 * np.sin(np.pi * p)
    prev = prev + a * (noise[i] - prev)
    out[i] = prev
env = np.sin(np.pi * np.clip(tt / 0.7, 0, 1)) ** 2
out = out * env
out /= np.max(np.abs(out)) * 1.2
write_wav("whoosh.wav", out)

# Hit / impacto
n = int(1.2 * SR)
tt = np.arange(n) / SR
thump = np.sin(2 * np.pi * (40 + 110 * np.exp(-tt * 18)) * tt) * np.exp(-tt * 4.5)
burst = rng.normal(0, 1, n) * np.exp(-tt * 30) * 0.35
hit = thump + burst
hit /= np.max(np.abs(hit)) * 1.1
write_wav("hit.wav", hit)
print("Audio OK")
