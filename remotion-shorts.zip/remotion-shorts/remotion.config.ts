import {Config} from "@remotion/cli/config";

// Ajustes de render para Shorts / TikTok (H.264 + AAC, yuv420p).
Config.setVideoImageFormat("jpeg");
Config.setJpegQuality(95);
Config.setCodec("h264");
Config.setPixelFormat("yuv420p");
Config.setCrf(18);
Config.setOverwriteOutput(true);
