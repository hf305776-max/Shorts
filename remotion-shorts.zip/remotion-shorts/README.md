# Remotion Shorts — video vertical cinematográfico (1080x1920 · 30 FPS · 30 s)

Plantilla para YouTube Shorts / TikTok / Reels hecha con **Remotion 4** y React.
Todo el contenido editable está en **`src/config.ts`**.

## Estructura

```
remotion-shorts/
├── package.json
├── tsconfig.json
├── remotion.config.ts          # ajustes de render (H.264, CRF 18)
├── scripts/generate_placeholders.py   # (opcional) regenera imágenes/audio de ejemplo
├── public/                     # TUS recursos multimedia
│   ├── images/scene-1.jpg … scene-6.jpg
│   ├── videos/                 # pon aquí clips .mp4
│   └── audio/
│       ├── music.wav           # música de fondo
│       ├── whoosh.wav          # sonido de transición
│       └── hit.wav             # impacto del primer frame
└── src/
    ├── index.ts                # registerRoot
    ├── Root.tsx                # <Composition id="Short" …>
    ├── ShortVideo.tsx          # composición principal
    ├── config.ts               # ← TEXTOS, FONDOS, SUBTÍTULOS, AUDIO, EFECTOS
    ├── lib/                    # timeline, fuentes, transiciones, rutas
    └── components/             # Backdrop, AnimatedTitle, Subtitles, Overlays, AudioTrack, Scene
```

## Instalación y uso

Requisitos: **Node.js 18 o superior** (recomendado 20/22) e internet la primera vez
(descarga Chrome Headless y las fuentes de Google Fonts).

```bash
npm install
npm start            # abre Remotion Studio para previsualizar
npm run render       # exporta out/short.mp4
npm run render:hq    # calidad mayor (CRF 15)
npm run thumbnail    # imagen de portada out/thumbnail.png
npm run typecheck    # comprueba tipos
```

Si quieres la última versión 4.x de Remotion: `npx remotion upgrade`
(todos los paquetes `remotion` y `@remotion/*` deben tener la MISMA versión).

## Cómo cambiar cosas

**Textos:** en `scenes[].title` y `scenes[].kicker`. Resalta palabras con asteriscos: `"EL *99%* NO SABE ESTO"`.

**Imágenes:** copia tu archivo a `public/images/` y cambia `media.src`, por ejemplo `"images/mi-foto.jpg"`.

**Videos de fondo:** copia el `.mp4` a `public/videos/` y usa
`media: {type: "video", src: "videos/mi-clip.mp4"}`. Sin fondo: `media: {type: "none"}`.

**Cámara y transiciones:** `camera` = `zoom-in | zoom-out | pan-left | pan-right | pan-up`.
`transition` = `fade | slide-up | slide-left | wipe | flip` (es la transición hacia la escena siguiente).

**Duración:** el video siempre dura `DURATION_SECONDS` (30 s). La última escena se ajusta sola.
Para añadir o quitar escenas, agrega o borra objetos en `scenes`.

**Subtítulos:** edita `captions` (`text`, `start`, `end` en segundos). Se resalta la palabra activa.
Si grabas una narración, ajusta los tiempos a lo que dice la voz. También puedes generar tiempos
automáticamente con Whisper (`@remotion/install-whisper-cpp`) y volcar el resultado a ese formato.

**Audio:**
- Música: reemplaza `public/audio/music.wav` por tu archivo (mp3/wav/aac) o cambia `audio.music.src`.
- Narración: `audio.voiceover.src = "audio/voz.mp3"` (la música baja de volumen sola).
- Efectos: cambia `whoosh`, `hit` o añade más en `extraSfx: [{src: "audio/ding.mp3", at: 12, volume: 0.7}]`.
- Para quitar un sonido: pon su `src` en `null`.

**Efectos visuales:** en `effects` (grano, viñeta, temblor de cámara, destello inicial, barra de progreso, fugas de luz).

**Colores:** `theme` (texto y subtítulos) y `accent` de cada escena.

**Textos por línea de comandos (sin tocar código):**
```bash
npx remotion render src/index.ts Short out/otro.mp4 --props=./mis-props.json
```
El JSON puede traer solo las claves que quieras reemplazar de `VideoProps`
(`theme`, `effects`, `scenes`, `captions`, `audio`) — las que incluyas deben estar completas.

## Zonas seguras

Los subtítulos están a ~400 px del borde inferior y el título deja margen para que la interfaz de
TikTok/Shorts (botones y descripción) no los tape.

## Problemas frecuentes

- **Falla la descarga de fuentes:** necesitas internet en el primer render. Alternativa: usa una fuente
  local con `@font-face` y `staticFile()` en `src/lib/fonts.ts`.
- **Render lento:** baja el grano (`effects.grain = 0`) o usa `--concurrency=2` si tienes poca RAM.
- **Un archivo no carga:** verifica que la ruta sea relativa a `public/` (sin `/` inicial).
- **Audio .mp3 sin sonido en el MP4:** usa el códec por defecto (`h264` + `aac`); no pases `--muted`.
