import {staticFile} from "remotion";

/**
 * Convierte una ruta relativa a /public en una URL valida.
 * Tambien acepta URLs https:// o data: tal cual.
 */
export const resolveSrc = (src: string): string => {
  if (/^(https?:|data:|blob:)/i.test(src)) {
    return src;
  }
  return staticFile(src);
};
