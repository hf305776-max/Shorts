import {FPS, TOTAL_FRAMES, TRANSITION_FRAMES} from "../config";
import type {SceneConfig} from "../config";

export type Timeline = {
  /** Duracion en frames de cada escena (incluye el solape) */
  durations: number[];
  /** Frame global en el que empieza cada escena */
  starts: number[];
};

/**
 * Con <TransitionSeries>, la duracion total es:
 *   suma(escenas) - (n - 1) * TRANSITION_FRAMES
 * La ultima escena absorbe la diferencia para que el video dure
 * EXACTAMENTE TOTAL_FRAMES (30 s).
 */
export const buildTimeline = (scenes: SceneConfig[]): Timeline => {
  const n = scenes.length;
  if (n < 1) {
    throw new Error("Necesitas al menos una escena en src/config.ts");
  }

  const minFrames = TRANSITION_FRAMES * 2;
  const durations = scenes.map((s) =>
    Math.max(minFrames, Math.round(s.seconds * FPS)),
  );

  const overlap = (n - 1) * TRANSITION_FRAMES;
  const usedByOthers = durations
    .slice(0, -1)
    .reduce((acc, d) => acc + d, 0);
  const last = TOTAL_FRAMES + overlap - usedByOthers;

  if (last < minFrames) {
    throw new Error(
      "Las escenas suman demasiado tiempo. Reduce 'seconds' en alguna escena de src/config.ts.",
    );
  }
  durations[n - 1] = last;

  const starts: number[] = [];
  let cursor = 0;
  for (const d of durations) {
    starts.push(cursor);
    cursor += d - TRANSITION_FRAMES;
  }

  return {durations, starts};
};
