import {loadFont as loadAnton} from "@remotion/google-fonts/Anton";
import {loadFont as loadMontserrat} from "@remotion/google-fonts/Montserrat";

/**
 * Las fuentes se descargan de Google Fonts la primera vez que se
 * renderiza (hace falta internet). Para cambiarlas, importa otra
 * fuente de "@remotion/google-fonts/<Nombre>" o usa una local con
 * @font-face + staticFile().
 */
const anton = loadAnton("normal", {weights: ["400"], subsets: ["latin"]});
const montserrat = loadMontserrat("normal", {
  weights: ["800"],
  subsets: ["latin"],
});

export const TITLE_FONT = `${anton.fontFamily}, Impact, "Arial Black", sans-serif`;
export const CAPTION_FONT = `${montserrat.fontFamily}, "Arial Black", Arial, sans-serif`;
