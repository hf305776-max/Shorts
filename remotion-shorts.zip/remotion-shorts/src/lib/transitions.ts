import type {TransitionPresentation} from "@remotion/transitions";
import {fade} from "@remotion/transitions/fade";
import {flip} from "@remotion/transitions/flip";
import {slide} from "@remotion/transitions/slide";
import {wipe} from "@remotion/transitions/wipe";
import type {TransitionType} from "../config";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export const getPresentation = (type: TransitionType): TransitionPresentation<any> => {
  switch (type) {
    case "slide-up":
      return slide({direction: "from-bottom"});
    case "slide-left":
      return slide({direction: "from-right"});
    case "wipe":
      return wipe({direction: "from-left"});
    case "flip":
      return flip({direction: "from-right"});
    case "fade":
    default:
      return fade();
  }
};
