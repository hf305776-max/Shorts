import React from "react";
import {Composition} from "remotion";
import {ShortVideo} from "./ShortVideo";
import {defaultProps, FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from "./config";

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id="Short"
      component={ShortVideo}
      durationInFrames={TOTAL_FRAMES}
      fps={FPS}
      width={WIDTH}
      height={HEIGHT}
      defaultProps={defaultProps}
    />
  );
};
