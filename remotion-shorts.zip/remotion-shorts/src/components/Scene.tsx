import React from "react";
import {AbsoluteFill} from "remotion";
import type {SceneConfig, Theme, Effects} from "../config";
import {AnimatedTitle} from "./AnimatedTitle";
import {Backdrop} from "./Backdrop";

type Props = {
  scene: SceneConfig;
  theme: Theme;
  effects: Effects;
};

export const Scene: React.FC<Props> = ({scene, theme, effects}) => {
  return (
    <AbsoluteFill>
      <Backdrop
        media={scene.media}
        camera={scene.camera}
        accent={scene.accent}
        shake={effects.shake}
      />
      <AnimatedTitle
        title={scene.title}
        kicker={scene.kicker}
        accent={scene.accent}
        textColor={theme.textColor}
      />
    </AbsoluteFill>
  );
};
