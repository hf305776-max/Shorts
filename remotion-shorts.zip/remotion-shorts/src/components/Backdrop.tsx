import React from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  OffthreadVideo,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import type {CameraMove, MediaType} from "../config";
import {resolveSrc} from "../lib/assets";

type Props = {
  media: {type: MediaType; src?: string};
  camera: CameraMove;
  accent: string;
  shake: number;
};

const fill: React.CSSProperties = {
  width: "100%",
  height: "100%",
  objectFit: "cover",
};

/**
 * Fondo de la escena con movimiento de camara simulado
 * (Ken Burns + pulso de camara en mano + "punch" de entrada)
 * y correccion de color cinematografica.
 */
export const Backdrop: React.FC<Props> = ({media, camera, accent, shake}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const p = interpolate(frame, [0, durationInFrames], [0, 1], {
    easing: Easing.inOut(Easing.quad),
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  let scale = 1.2;
  let tx = 0;
  let ty = 0;
  switch (camera) {
    case "zoom-in":
      scale = interpolate(p, [0, 1], [1.12, 1.34]);
      break;
    case "zoom-out":
      scale = interpolate(p, [0, 1], [1.36, 1.12]);
      break;
    case "pan-left":
      scale = 1.26;
      tx = interpolate(p, [0, 1], [70, -70]);
      break;
    case "pan-right":
      scale = 1.26;
      tx = interpolate(p, [0, 1], [-70, 70]);
      break;
    case "pan-up":
      scale = 1.26;
      ty = interpolate(p, [0, 1], [90, -90]);
      break;
  }

  // "Punch" de entrada: un pequeno golpe de zoom al empezar la escena
  const punch = interpolate(frame, [0, 10], [0.1, 0], {
    easing: Easing.out(Easing.cubic),
    extrapolateRight: "clamp",
  });

  // Camara en mano simulada
  const sx = (Math.sin(frame / 9) * 5 + Math.sin(frame / 3.7) * 2.5) * shake;
  const sy = (Math.cos(frame / 11) * 5 + Math.cos(frame / 4.3) * 2.5) * shake;
  const rot = Math.sin(frame / 23) * 0.35 * shake;

  const transform = `translate(${tx + sx}px, ${ty + sy}px) scale(${
    scale + punch
  }) rotate(${rot}deg)`;

  const src = media.src;

  return (
    <AbsoluteFill style={{backgroundColor: "#050505", overflow: "hidden"}}>
      <AbsoluteFill
        style={{
          transform,
          transformOrigin: "50% 50%",
          // Correccion de color: mas contraste y saturacion, algo oscuro
          filter: "contrast(1.12) saturate(1.15) brightness(0.9)",
        }}
      >
        {media.type === "image" && src ? (
          <Img src={resolveSrc(src)} style={fill} />
        ) : media.type === "video" && src ? (
          <OffthreadVideo src={resolveSrc(src)} muted style={fill} />
        ) : (
          <AbsoluteFill
            style={{
              background: `radial-gradient(circle at 50% 35%, ${accent}66 0%, #0a0a14 70%)`,
            }}
          />
        )}
      </AbsoluteFill>

      {/* Tinte cine (azul-teal arriba, calido abajo) */}
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(180deg, rgba(0,50,90,0.28) 0%, rgba(255,120,40,0.14) 100%)",
          mixBlendMode: "soft-light",
        }}
      />

      {/* Oscurecer para que el texto se lea bien */}
      <AbsoluteFill
        style={{
          background:
            "linear-gradient(180deg, rgba(0,0,0,0.35) 0%, rgba(0,0,0,0.15) 35%, rgba(0,0,0,0.65) 100%)",
        }}
      />
    </AbsoluteFill>
  );
};
