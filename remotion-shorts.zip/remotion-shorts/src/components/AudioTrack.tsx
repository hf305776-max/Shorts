import React from "react";
import {Audio, Sequence, interpolate, useVideoConfig} from "remotion";
import type {AudioConfig} from "../config";
import {resolveSrc} from "../lib/assets";

type Props = {
  audio: AudioConfig;
  /** Frames globales donde empieza cada transicion (para el whoosh) */
  transitionStarts: number[];
};

/**
 * Musica (con fade in/out y "ducking" si hay narracion), narracion,
 * impacto inicial, whoosh en cada transicion y efectos extra.
 * Cualquier src en null se omite.
 */
export const AudioTrack: React.FC<Props> = ({audio, transitionStarts}) => {
  const {fps, durationInFrames} = useVideoConfig();

  const hasVoice = Boolean(audio.voiceover.src);
  const musicVolume = hasVoice ? audio.music.volume * 0.45 : audio.music.volume;

  return (
    <>
      {audio.music.src ? (
        <Audio
          src={resolveSrc(audio.music.src)}
          loop
          volume={(f) =>
            interpolate(
              f,
              [0, fps, durationInFrames - fps * 1.5, durationInFrames],
              [0, musicVolume, musicVolume, 0],
              {extrapolateLeft: "clamp", extrapolateRight: "clamp"},
            )
          }
        />
      ) : null}

      {audio.voiceover.src ? (
        <Audio
          src={resolveSrc(audio.voiceover.src)}
          volume={audio.voiceover.volume}
        />
      ) : null}

      {audio.hit.src ? (
        <Sequence from={0} name="SFX hit">
          <Audio src={resolveSrc(audio.hit.src)} volume={audio.hit.volume} />
        </Sequence>
      ) : null}

      {audio.whoosh.src
        ? transitionStarts.map((start, i) => (
            <Sequence
              key={`whoosh-${i}`}
              from={Math.max(0, start - 4)}
              name={`SFX whoosh ${i + 1}`}
            >
              <Audio
                src={resolveSrc(audio.whoosh.src as string)}
                volume={audio.whoosh.volume}
              />
            </Sequence>
          ))
        : null}

      {audio.extraSfx.map((sfx, i) => (
        <Sequence
          key={`sfx-${i}`}
          from={Math.max(0, Math.round(sfx.at * fps))}
          name={`SFX extra ${i + 1}`}
        >
          <Audio src={resolveSrc(sfx.src)} volume={sfx.volume ?? 0.7} />
        </Sequence>
      ))}
    </>
  );
};
