import React from "react";
import {
  AbsoluteFill,
  Sequence,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import type {Caption, Theme} from "../config";
import {CAPTION_FONT} from "../lib/fonts";

type Props = {
  captions: Caption[];
  theme: Theme;
};

/** Frame (relativo al subtitulo) en que empieza cada palabra */
const getWordStarts = (words: string[], durationInFrames: number): number[] => {
  const weights = words.map((w) => w.length + 2);
  const total = weights.reduce((a, b) => a + b, 0);
  let acc = 0;
  return weights.map((wt) => {
    const start = Math.round((acc / total) * durationInFrames);
    acc += wt;
    return start;
  });
};

const CaptionLine: React.FC<{
  caption: Caption;
  durationInFrames: number;
  theme: Theme;
}> = ({caption, durationInFrames, theme}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const words = caption.text.split(/\s+/).filter(Boolean);
  const starts = getWordStarts(words, durationInFrames);

  let active = 0;
  starts.forEach((s, i) => {
    if (frame >= s) {
      active = i;
    }
  });

  const pop = spring({
    frame,
    fps,
    config: {damping: 13, stiffness: 200, mass: 0.6},
  });
  const fadeOut = interpolate(
    frame,
    [durationInFrames - 4, durationInFrames],
    [1, 0],
    {extrapolateLeft: "clamp", extrapolateRight: "clamp"},
  );

  return (
    <AbsoluteFill
      style={{
        justifyContent: "flex-end",
        alignItems: "center",
        paddingBottom: 400,
        paddingLeft: 60,
        paddingRight: 60,
      }}
    >
      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          columnGap: 22,
          rowGap: 6,
          maxWidth: 960,
          opacity: Math.min(1, pop * 2) * fadeOut,
          transform: `scale(${interpolate(pop, [0, 1], [0.85, 1])}) translateY(${interpolate(
            pop,
            [0, 1],
            [30, 0],
          )}px)`,
        }}
      >
        {words.map((word, i) => {
          const isActive = i === active;
          const reached = i <= active;
          const wordSpring = spring({
            frame: frame - starts[i],
            fps,
            config: {damping: 12, stiffness: 240, mass: 0.5},
          });
          const wordScale = isActive
            ? interpolate(wordSpring, [0, 1], [0.85, 1.14], {
                extrapolateRight: "clamp",
              })
            : 1;

          return (
            <span
              key={`${word}-${i}`}
              style={{
                display: "inline-block",
                fontFamily: CAPTION_FONT,
                fontWeight: 800,
                fontSize: 74,
                lineHeight: 1.12,
                textTransform: "uppercase",
                color: isActive ? theme.captionActiveColor : theme.captionColor,
                opacity: reached ? 1 : 0.45,
                transform: `scale(${wordScale})`,
                WebkitTextStroke: "12px #000",
                paintOrder: "stroke fill",
                textShadow: "0 8px 24px rgba(0,0,0,0.55)",
              }}
            >
              {word}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

export const Subtitles: React.FC<Props> = ({captions, theme}) => {
  const {fps} = useVideoConfig();

  return (
    <>
      {captions.map((c, i) => {
        const from = Math.round(c.start * fps);
        const duration = Math.max(1, Math.round((c.end - c.start) * fps));
        return (
          <Sequence
            key={`${c.start}-${i}`}
            from={from}
            durationInFrames={duration}
            name={`Caption ${i + 1}`}
          >
            <CaptionLine caption={c} durationInFrames={duration} theme={theme} />
          </Sequence>
        );
      })}
    </>
  );
};
