import React from "react";
import {
  AbsoluteFill,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

/** Oscurece los bordes para dar look de cine */
export const Vignette: React.FC<{intensity: number}> = ({intensity}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 50%, rgba(0,0,0,${intensity}) 100%)`,
      pointerEvents: "none",
    }}
  />
);

/** Grano de pelicula (ruido que cambia cada 2 frames) */
export const FilmGrain: React.FC<{opacity: number}> = ({opacity}) => {
  const frame = useCurrentFrame();
  const seed = Math.floor(frame / 2);

  return (
    <AbsoluteFill
      style={{opacity, mixBlendMode: "overlay", pointerEvents: "none"}}
    >
      <svg
        width="100%"
        height="100%"
        viewBox="0 0 540 960"
        preserveAspectRatio="none"
      >
        <filter id="film-grain" x="0" y="0" width="100%" height="100%">
          <feTurbulence
            type="fractalNoise"
            baseFrequency="0.9"
            numOctaves={2}
            seed={seed}
            stitchTiles="stitch"
          />
          <feColorMatrix
            type="matrix"
            values="0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0.33 0.33 0.33 0 0  0 0 0 0 1"
          />
        </filter>
        <rect width="540" height="960" filter="url(#film-grain)" />
      </svg>
    </AbsoluteFill>
  );
};

/** Fuga de luz calida que se desplaza por el cuadro */
export const LightLeak: React.FC = () => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();

  const x = interpolate(frame, [0, durationInFrames], [-10, 110]);
  const pulse = 0.14 + 0.1 * Math.sin(frame / 25);

  return (
    <AbsoluteFill
      style={{
        background: `radial-gradient(ellipse 55% 40% at ${x}% 18%, rgba(255,140,60,0.9), rgba(255,60,90,0) 70%)`,
        mixBlendMode: "screen",
        opacity: pulse,
        pointerEvents: "none",
      }}
    />
  );
};

/** Destello blanco al inicio (gancho visual) */
export const StartFlash: React.FC = () => {
  const frame = useCurrentFrame();
  const opacity = interpolate(frame, [0, 8], [0.9, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  if (opacity <= 0) {
    return null;
  }
  return (
    <AbsoluteFill
      style={{backgroundColor: "#fff", opacity, pointerEvents: "none"}}
    />
  );
};

/** Barra de progreso superior */
export const ProgressBar: React.FC<{color: string}> = ({color}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const width = interpolate(frame, [0, durationInFrames], [0, 100], {
    extrapolateRight: "clamp",
  });
  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        height: 10,
        width: `${width}%`,
        backgroundColor: color,
        boxShadow: `0 0 20px ${color}`,
      }}
    />
  );
};
