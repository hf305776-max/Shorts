import React from "react";
import {
  AbsoluteFill,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import {TITLE_FONT, CAPTION_FONT} from "../lib/fonts";

type Props = {
  title: string;
  kicker?: string;
  accent: string;
  textColor: string;
};

type Word = {text: string; highlight: boolean};

/** "EL *99%* NO SABE" -> palabras con flag de resaltado */
const parseTitle = (text: string): Word[] =>
  text.split("*").flatMap((part, i) =>
    part
      .split(/\s+/)
      .filter(Boolean)
      .map((w) => ({text: w, highlight: i % 2 === 1})),
  );

export const AnimatedTitle: React.FC<Props> = ({
  title,
  kicker,
  accent,
  textColor,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  const words = parseTitle(title);
  const plainLength = title.replace(/\*/g, "").length;
  const fontSize = plainLength <= 16 ? 200 : plainLength <= 26 ? 170 : 145;

  const START = 8; // frames de espera (coincide con la transicion)
  const STAGGER = 4;

  // Etiqueta superior
  const kickerSpring = spring({
    frame: frame - START + 4,
    fps,
    config: {damping: 14, stiffness: 160},
  });

  // Barra de acento bajo el titulo
  const barDelay = START + words.length * STAGGER + 4;
  const barSpring = spring({
    frame: frame - barDelay,
    fps,
    config: {damping: 16, stiffness: 120},
  });

  return (
    <AbsoluteFill
      style={{
        justifyContent: "center",
        alignItems: "center",
        paddingLeft: 70,
        paddingRight: 70,
        paddingBottom: 380,
        paddingTop: 120,
      }}
    >
      {kicker ? (
        <div
          style={{
            fontFamily: CAPTION_FONT,
            fontWeight: 800,
            fontSize: 46,
            letterSpacing: 6,
            textTransform: "uppercase",
            color: "#0b0b0b",
            backgroundColor: accent,
            padding: "14px 34px",
            borderRadius: 999,
            marginBottom: 44,
            transform: `translateX(${interpolate(
              kickerSpring,
              [0, 1],
              [-420, 0],
            )}px)`,
            opacity: interpolate(kickerSpring, [0, 0.4], [0, 1], {
              extrapolateRight: "clamp",
            }),
            boxShadow: `0 10px 40px ${accent}66`,
          }}
        >
          {kicker}
        </div>
      ) : null}

      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          justifyContent: "center",
          alignItems: "center",
          columnGap: 28,
          rowGap: 4,
          maxWidth: 940,
        }}
      >
        {words.map((w, i) => {
          const local = frame - (START + i * STAGGER);
          const s = spring({
            frame: local,
            fps,
            config: {damping: 11, stiffness: 150, mass: 0.6},
          });
          const opacity = interpolate(local, [0, 5], [0, 1], {
            extrapolateLeft: "clamp",
            extrapolateRight: "clamp",
          });
          const y = interpolate(s, [0, 1], [90, 0]);
          const scale = interpolate(s, [0, 1], [1.6, 1]);
          const rotate = interpolate(s, [0, 1], [i % 2 === 0 ? -6 : 6, 0]);
          const blur = Math.max(
            0,
            interpolate(s, [0, 1], [18, 0], {extrapolateRight: "clamp"}),
          );
          const float = local > 20 ? Math.sin((frame + i * 9) / 18) * 4 : 0;

          return (
            <span
              key={`${w.text}-${i}`}
              style={{
                display: "inline-block",
                fontFamily: TITLE_FONT,
                fontSize,
                lineHeight: 1.02,
                textTransform: "uppercase",
                color: w.highlight ? accent : textColor,
                opacity,
                filter: `blur(${blur}px)`,
                transform: `translateY(${y + float}px) scale(${scale}) rotate(${rotate}deg)`,
                textShadow: w.highlight
                  ? `0 0 50px ${accent}99, 0 10px 0 rgba(0,0,0,0.5)`
                  : "0 10px 0 rgba(0,0,0,0.5), 0 14px 50px rgba(0,0,0,0.7)",
              }}
            >
              {w.text}
            </span>
          );
        })}
      </div>

      <div
        style={{
          marginTop: 44,
          height: 14,
          width: interpolate(barSpring, [0, 1], [0, 260]),
          borderRadius: 999,
          backgroundColor: accent,
          boxShadow: `0 0 30px ${accent}aa`,
        }}
      />
    </AbsoluteFill>
  );
};
