/**
 * ============================================================
 *  CONFIGURACION DEL VIDEO  -  TODO LO EDITABLE ESTA AQUI
 * ============================================================
 *  - Textos de cada escena (titulo, etiqueta superior)
 *  - Imagenes / videos de fondo (rutas dentro de /public)
 *  - Subtitulos sincronizados (en segundos)
 *  - Musica, narracion y efectos de sonido
 *  - Colores y efectos visuales
 *
 *  Resaltar palabras del titulo: enciérralas entre asteriscos.
 *  Ejemplo:  "EL *99%* NO SABE ESTO"
 * ============================================================
 */

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const DURATION_SECONDS = 30;
export const TOTAL_FRAMES = FPS * DURATION_SECONDS; // 900
/** Duracion (en frames) del solape entre escenas. 15 = 0.5 s */
export const TRANSITION_FRAMES = 15;

export type MediaType = "image" | "video" | "none";
export type CameraMove =
  | "zoom-in"
  | "zoom-out"
  | "pan-left"
  | "pan-right"
  | "pan-up";
export type TransitionType =
  | "fade"
  | "slide-up"
  | "slide-left"
  | "wipe"
  | "flip";

export type SceneConfig = {
  id: string;
  /**
   * Duracion de la escena en segundos (incluye el solape de transicion).
   * La ULTIMA escena se ajusta sola para que el video dure exactamente
   * DURATION_SECONDS.
   */
  seconds: number;
  /** Fondo: imagen, video o ninguno. `src` es relativo a /public */
  media: {type: MediaType; src?: string};
  /** Etiqueta pequena sobre el titulo (opcional) */
  kicker?: string;
  /** Titulo grande. Usa *asteriscos* para resaltar palabras. */
  title: string;
  /** Movimiento de camara simulado */
  camera: CameraMove;
  /** Color de acento de la escena (titulo resaltado, etiqueta, brillo) */
  accent: string;
  /** Transicion que se usa para pasar a la SIGUIENTE escena */
  transition: TransitionType;
};

/** Subtitulo: tiempos en segundos sobre la linea de tiempo global del video */
export type Caption = {text: string; start: number; end: number};

export type SfxCue = {src: string; at: number; volume?: number};

export type AudioConfig = {
  /** Musica de fondo (se repite si es mas corta que el video) */
  music: {src: string | null; volume: number};
  /** Narracion / voz en off. null = sin narracion */
  voiceover: {src: string | null; volume: number};
  /** Sonido que suena en cada transicion */
  whoosh: {src: string | null; volume: number};
  /** Impacto en el frame 0 (gancho) */
  hit: {src: string | null; volume: number};
  /** Efectos extra en momentos concretos (segundos) */
  extraSfx: SfxCue[];
};

export type Theme = {
  textColor: string;
  captionColor: string;
  captionActiveColor: string;
};

export type Effects = {
  /** 0 = sin grano, 0.12 = recomendado */
  grain: number;
  /** 0 = sin vineta, 0.7 = fuerte */
  vignette: number;
  /** 0 = camara fija, 1 = pulso a mano normal, 2 = fuerte */
  shake: number;
  /** Destello blanco en el primer frame */
  flashOnStart: boolean;
  /** Barra de progreso arriba (mejora la retencion) */
  progressBar: boolean;
  /** Fugas de luz animadas */
  lightLeak: boolean;
};

export type VideoProps = {
  theme: Theme;
  effects: Effects;
  scenes: SceneConfig[];
  captions: Caption[];
  audio: AudioConfig;
};

export const defaultProps: VideoProps = {
  theme: {
    textColor: "#FFFFFF",
    captionColor: "#FFFFFF",
    captionActiveColor: "#FFD21F",
  },

  effects: {
    grain: 0.12,
    vignette: 0.6,
    shake: 1,
    flashOnStart: true,
    progressBar: true,
    lightLeak: true,
  },

  // ---------------------------------------------------------------
  //  ESCENAS (ajusta textos, fondos, camara y transiciones)
  //  Para usar VIDEO de fondo:
  //    media: {type: "video", src: "videos/mi-clip.mp4"}
  // ---------------------------------------------------------------
  scenes: [
    {
      id: "hook",
      seconds: 5,
      media: {type: "image", src: "images/scene-1.jpg"},
      kicker: "ATENCIÓN",
      title: "EL *99%* NO SABE ESTO",
      camera: "zoom-in",
      accent: "#FFC21A",
      transition: "slide-up",
    },
    {
      id: "problem",
      seconds: 5.5,
      media: {type: "image", src: "images/scene-2.jpg"},
      kicker: "LA VERDAD",
      title: "TU CEREBRO TE *ENGAÑA*",
      camera: "pan-left",
      accent: "#FF4D6D",
      transition: "wipe",
    },
    {
      id: "solution",
      seconds: 5.5,
      media: {type: "image", src: "images/scene-3.jpg"},
      kicker: "LA SOLUCIÓN",
      title: "LA REGLA DE LOS *5 SEGUNDOS*",
      camera: "zoom-out",
      accent: "#3DF5C8",
      transition: "fade",
    },
    {
      id: "action",
      seconds: 5.5,
      media: {type: "image", src: "images/scene-4.jpg"},
      kicker: "SIN EXCUSAS",
      title: "NO PIENSES. *ACTÚA*",
      camera: "pan-right",
      accent: "#FFB347",
      transition: "slide-left",
    },
    {
      id: "result",
      seconds: 5.5,
      media: {type: "image", src: "images/scene-5.jpg"},
      kicker: "RESULTADOS",
      title: "LA *CONSTANCIA* HACE EL RESTO",
      camera: "pan-up",
      accent: "#9D8CFF",
      transition: "flip",
    },
    {
      id: "cta",
      seconds: 5.5, // se ajusta automaticamente
      media: {type: "image", src: "images/scene-6.jpg"},
      kicker: "SÍGUEME PARA MÁS",
      title: "EMPIEZA *HOY*",
      camera: "zoom-in",
      accent: "#FF3B3B",
      transition: "fade",
    },
  ],

  // ---------------------------------------------------------------
  //  SUBTITULOS (segundos). Cada palabra se resalta al hablarse; el
  //  tiempo se reparte segun la longitud de cada palabra. Si tienes
  //  la narracion real, ajusta start/end a lo que dice la voz.
  // ---------------------------------------------------------------
  captions: [
    {text: "El noventa y nueve por ciento no sabe esto", start: 0.3, end: 2.6},
    {text: "y te cuesta años de progreso", start: 2.6, end: 4.4},
    {text: "Tu cerebro te engaña", start: 5.0, end: 7.0},
    {text: "para que sigas posponiendo todo", start: 7.0, end: 9.4},
    {text: "Pero existe una regla simple", start: 9.9, end: 12.0},
    {text: "cuenta hasta cinco y actúa", start: 12.0, end: 14.4},
    {text: "Sin pensar. Sin excusas.", start: 14.9, end: 17.0},
    {text: "Pequeños cambios, grandes resultados", start: 17.0, end: 19.4},
    {text: "Cada acción suma", start: 19.9, end: 22.0},
    {text: "y la constancia hace el resto", start: 22.0, end: 24.4},
    {text: "Empieza hoy", start: 24.9, end: 27.0},
    {text: "Sígueme para más", start: 27.0, end: 29.7},
  ],

  // ---------------------------------------------------------------
  //  AUDIO (rutas relativas a /public). Pon null para desactivar.
  // ---------------------------------------------------------------
  audio: {
    music: {src: "audio/music.wav", volume: 0.5},
    voiceover: {src: null, volume: 1}, // ej: "audio/voiceover.mp3"
    whoosh: {src: "audio/whoosh.wav", volume: 0.6},
    hit: {src: "audio/hit.wav", volume: 0.8},
    extraSfx: [
      // {src: "audio/ding.mp3", at: 12.0, volume: 0.7},
    ],
  },
};
