import React from "react";
import {AbsoluteFill, Easing} from "remotion";
import {TransitionSeries, linearTiming} from "@remotion/transitions";
import {TRANSITION_FRAMES} from "./config";
import type {VideoProps} from "./config";
import {AudioTrack} from "./components/AudioTrack";
import {
  FilmGrain,
  LightLeak,
  ProgressBar,
  StartFlash,
  Vignette,
} from "./components/Overlays";
import {Scene} from "./components/Scene";
import {Subtitles} from "./components/Subtitles";
import {buildTimeline} from "./lib/timeline";
import {getPresentation} from "./lib/transitions";

export const ShortVideo: React.FC<VideoProps> = ({
  theme,
  effects,
  scenes,
  captions,
  audio,
}) => {
  const {durations, starts} = buildTimeline(scenes);

  // La transicion i empieza cuando arranca la escena i+1
  const transitionStarts = starts.slice(1);

  const items: React.ReactNode[] = [];
  scenes.forEach((scene, i) => {
    items.push(
      <TransitionSeries.Sequence
        key={`scene-${scene.id}`}
        durationInFrames={durations[i]}
        name={scene.id}
      >
        <Scene scene={scene} theme={theme} effects={effects} />
      </TransitionSeries.Sequence>,
    );

    if (i < scenes.length - 1) {
      items.push(
        <TransitionSeries.Transition
          key={`transition-${scene.id}`}
          presentation={getPresentation(scene.transition)}
          timing={linearTiming({
            durationInFrames: TRANSITION_FRAMES,
            easing: Easing.inOut(Easing.ease),
          })}
        />,
      );
    }
  });

  return (
    <AbsoluteFill style={{backgroundColor: "#000"}}>
      <TransitionSeries>{items}</TransitionSeries>

      {effects.lightLeak ? <LightLeak /> : null}
      {effects.grain > 0 ? <FilmGrain opacity={effects.grain} /> : null}
      {effects.vignette > 0 ? <Vignette intensity={effects.vignette} /> : null}

      <Subtitles captions={captions} theme={theme} />

      {effects.progressBar ? (
        <ProgressBar color={theme.captionActiveColor} />
      ) : null}
      {effects.flashOnStart ? <StartFlash /> : null}

      <AudioTrack audio={audio} transitionStarts={transitionStarts} />
    </AbsoluteFill>
  );
};
